import { mkdir, readdir, readFile, rename, rm, stat, writeFile } from "node:fs/promises";
import { join } from "node:path";
import type { BrowserContext, Page } from "playwright";
import type { BrowserAgentCommand } from "../../../packages/domain/src/booking.ts";
import { agentHuman, agentPage, prepareBrowserAgent, runBrowserAgent } from "./browser-agent.ts";
import {
  capturePdfDownload,
  MAX_DOWNLOAD_BYTES,
  type PdfDownload,
  readDownloadFailures,
} from "./downloads.ts";
import { WorkerError } from "./errors.ts";
import { validatePublicUrl } from "./network.ts";
import { startEgressProxy } from "./proxy.ts";

export interface Session {
  id: string;
  title: string;
  url: string;
  status: "active" | "closed" | "error";
  updatedAt: string;
  archived?: boolean;
}
type Running = {
  context: BrowserContext;
  page: Page;
  touched: number;
  pending: Set<Promise<void>>;
  downloadError?: boolean;
  viewport?: { width: number; height: number };
};
const SESSION_ID = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

export function validateSessionId(id: unknown): string {
  if (typeof id !== "string" || !SESSION_ID.test(id))
    throw new WorkerError("INVALID_SESSION", "A valid UUID session ID is required.");
  return id.toLowerCase();
}

export async function createBrowserManager(
  options: {
    dataDir: string;
    maxSessions?: number;
    maxProfiles?: number;
    idleTimeoutMs?: number;
    headless?: boolean;
    upstreamProxyUrl?: string;
    browserChannel?: string;
  },
  createProxy = () => startEgressProxy(undefined, { upstreamUrl: options.upstreamProxyUrl }),
) {
  const {
    dataDir,
    maxSessions = 6,
    maxProfiles = 20,
    idleTimeoutMs = 30 * 60_000,
    headless = true,
  } = options;
  if (!Number.isInteger(maxProfiles) || maxProfiles < 1)
    throw new Error("maxProfiles must be positive");
  await mkdir(dataDir, { recursive: true, mode: 0o700 });
  const archiveDir = join(dataDir, "archived");
  await mkdir(archiveDir, { recursive: true, mode: 0o700 });
  const archived = new Set<string>();
  const sessions = new Map<string, Session>();
  const running = new Map<string, Running>();
  const queues = new Map<string, Promise<unknown>>();
  const proxy = await createProxy();
  const directory = (id: string) =>
    join(archived.has(id) ? archiveDir : dataDir, validateSessionId(id));
  const temporaryDirectory = (id: string) =>
    join("/tmp", `openmuse-downloads-${validateSessionId(id)}`);
  for (const [folder, cold] of [
    [dataDir, false],
    [archiveDir, true],
  ] as const) {
    for (const id of await readdir(folder)) {
      if (!SESSION_ID.test(id) || sessions.has(id)) continue;
      try {
        const stored = JSON.parse(
          await readFile(join(folder, id, "session.json"), "utf8"),
        ) as Session;
        if (cold) archived.add(id);
        sessions.set(id, { ...stored, id, status: "closed", archived: cold });
      } catch {
        /* Incomplete metadata is not a restorable profile. */
      }
      if (sessions.has(id)) {
        await rm(temporaryDirectory(id), { recursive: true, force: true });
        await readDownloadFailures(directory(id), true);
      }
    }
  }
  async function persist(session: Session) {
    const path = join(directory(session.id), "session.json");
    await writeFile(`${path}.tmp`, JSON.stringify(session), { mode: 0o600 });
    await rename(`${path}.tmp`, path);
  }
  async function serial<T>(id: string, fn: () => Promise<T>): Promise<T> {
    const previous = queues.get(id) ?? Promise.resolve();
    const next = previous.catch(() => {}).then(fn);
    queues.set(id, next);
    try {
      return await next;
    } finally {
      if (queues.get(id) === next) queues.delete(id);
    }
  }
  function active(id: string) {
    const value = running.get(id);
    if (value) value.page = agentPage(value.page);
    if (!value || value.page.isClosed())
      throw new WorkerError(
        "SESSION_CLOSED",
        "Open this browser session before using its console.",
        409,
      );
    value.touched = Date.now();
    return value;
  }
  async function refresh(id: string) {
    const instance = active(id);
    if (instance.page.url() !== "about:blank") await validatePublicUrl(instance.page.url());
    const session: Session = {
      id,
      archived: false,
      title: (await instance.page.title()).slice(0, 300),
      url: instance.page.url(),
      status: "active",
      updatedAt: new Date().toISOString(),
    };
    sessions.set(id, session);
    await persist(session);
    return session;
  }
  async function downloads(id: string): Promise<PdfDownload[]> {
    if (!sessions.has(id))
      throw new WorkerError("SESSION_NOT_FOUND", "Browser session not found.", 404);
    const folder = join(directory(id), "downloads");
    await mkdir(folder, { recursive: true, mode: 0o700 });
    const list: PdfDownload[] = [];
    for (const name of await readdir(folder)) {
      if (!name.endsWith(".json")) continue;
      const item = JSON.parse(await readFile(join(folder, name), "utf8")) as PdfDownload;
      list.push(item);
    }
    return list;
  }
  async function navigate(id: string, url: string) {
    const target = await validatePublicUrl(url);
    const { page } = active(id);
    try {
      await page.goto(target.url.href, { waitUntil: "domcontentloaded", timeout: 20_000 });
      // Chromium can follow redirects outside Playwright's initial route hook.
      // The proxy blocks those sockets, but its 403 is still an HTTP response:
      // validate the final location so the API does not report it as success.
      await validatePublicUrl(page.url());
    } catch (error) {
      if (error instanceof WorkerError && error.code === "BLOCKED_URL") {
        await page.goto("about:blank", { timeout: 5000 });
      }
      // A successful attachment intentionally aborts page navigation.
      if (!(error instanceof Error && /Download is starting/.test(error.message))) {
        throw new WorkerError(
          error instanceof Error && error.message.includes("ERR_HTTP2_PROTOCOL_ERROR")
            ? "NAVIGATION_HTTP2_ERROR"
            : error instanceof Error && error.name === "TimeoutError"
              ? "NAVIGATION_TIMEOUT"
              : "NAVIGATION_FAILED",
          error instanceof Error && error.message.includes("ERR_HTTP2_PROTOCOL_ERROR")
            ? "The website interrupted the browser HTTP/2 connection. Use full browser mode (WORKER_HEADLESS=false)."
            : "The page could not be loaded. It may be unreachable or contain a blocked destination.",
          502,
          { cause: error },
        );
      }
    }
    return refresh(id);
  }
  async function closeSession(id: string, status: "closed" | "error" = "closed") {
    const instance = running.get(id);
    const stored = sessions.get(id);
    if (!stored) throw new WorkerError("SESSION_NOT_FOUND", "Browser session not found.", 404);
    if (instance) {
      if (status === "closed") {
        try {
          await instance.context.storageState({ path: join(directory(id), "storage.json") });
        } catch {
          // Cookie persistence is best-effort; a crashed browser must still be released.
        }
      }
      await instance.context.close().catch(() => {});
      await Promise.allSettled(instance.pending);
      running.delete(id);
    }
    // Completed downloads and persistent profiles live in /data, not this transient cache.
    await rm(temporaryDirectory(id), { recursive: true, force: true });
    const result: Session = { ...stored, status, updatedAt: new Date().toISOString() };
    sessions.set(id, result);
    await persist(result);
    return result;
  }
  async function sessionOperation<T>(id: string, operation: () => Promise<T>) {
    return serial(id, async () => {
      try {
        return await operation();
      } catch (error) {
        const unavailable =
          (error instanceof WorkerError && error.code === "SESSION_CLOSED") ||
          (error instanceof Error &&
            /(?:page|browser|target|context).*(?:crashed|closed)|ERR_INSUFFICIENT_RESOURCES/i.test(
              error.message,
            ));
        if (!unavailable) throw error;
        if (sessions.has(id)) await closeSession(id, "error");
        throw new WorkerError(
          "BROWSER_UNAVAILABLE",
          "The browser stopped responding and its session resources were released. Reopen it to continue; no page action was retried.",
          503,
          { cause: error },
        );
      }
    });
  }
  // Only inactive profiles are moved. Atomic same-volume renames retain cookies,
  // storage and downloads; no browsing data is deleted to make room for a task.
  async function reserveProfile(id: string) {
    if (sessions.has(id) && !archived.has(id)) return;
    while (sessions.size - archived.size >= maxProfiles) {
      const candidate = [...sessions.values()]
        .filter(
          (session) => session.id !== id && !archived.has(session.id) && !running.has(session.id),
        )
        .sort((a, b) => a.updatedAt.localeCompare(b.updatedAt))[0];
      if (!candidate)
        throw new WorkerError(
          "PROFILE_LIMIT",
          "All resident profiles are in use; close an unused session so it can be archived automatically.",
          409,
        );
      await serial(candidate.id, async () => {
        if (running.has(candidate.id) || archived.has(candidate.id)) return;
        const current = sessions.get(candidate.id);
        if (!current) return;
        await rename(join(dataDir, candidate.id), join(archiveDir, candidate.id));
        archived.add(candidate.id);
        const saved: Session = { ...current, status: "closed", archived: true };
        sessions.set(candidate.id, saved);
        await persist(saved);
      });
    }
    if (archived.has(id)) {
      const stored = sessions.get(id);
      if (!stored)
        throw new WorkerError("SESSION_NOT_FOUND", "Archived profile metadata missing", 404);
      await rename(join(archiveDir, id), join(dataDir, id));
      archived.delete(id);
      const saved = { ...stored, archived: false };
      sessions.set(id, saved);
      await persist(saved);
    }
  }
  async function createSession(
    id: string,
    url: string,
    agent = false,
    control?: "pause" | "handoff",
  ) {
    await validatePublicUrl(url);
    if (running.has(id)) {
      try {
        return await navigate(id, url);
      } catch (error) {
        await closeSession(id, "error");
        throw error;
      }
    }
    if (running.size >= maxSessions)
      throw new WorkerError(
        "SESSION_LIMIT",
        `Close an active session before opening another (limit ${maxSessions}).`,
        409,
      );
    await reserveProfile(id);
    const previous = sessions.get(id);
    const profileDir = join(directory(id), "profile");
    const tempDirectory = temporaryDirectory(id);
    await mkdir(profileDir, { recursive: true, mode: 0o700 });
    await mkdir(tempDirectory, { recursive: true, mode: 0o700 });
    let context: BrowserContext;
    try {
      const { chromium } = await import("playwright");
      context = await chromium.launchPersistentContext(profileDir, {
        // Chromium does not need the worker API credential in its environment.
        env: {
          HOME: process.env.HOME ?? "/tmp",
          PATH: process.env.PATH ?? "/usr/bin:/bin",
          LANG: "C.UTF-8",
          // Xvfb keeps full Chromium off the host desktop. Forward only its
          // display credentials, never the worker or provider environment.
          ...(process.env.DISPLAY ? { DISPLAY: process.env.DISPLAY } : {}),
          ...(process.env.XAUTHORITY ? { XAUTHORITY: process.env.XAUTHORITY } : {}),
          XDG_CONFIG_HOME: tempDirectory,
          XDG_CACHE_HOME: tempDirectory,
        },
        headless,
        // Use the container's dedicated /dev/shm instead of its small /tmp tmpfs.
        ignoreDefaultArgs: ["--disable-dev-shm-usage"],
        ...(options.browserChannel ? { channel: options.browserChannel } : {}),
        viewport: { width: 1280, height: 800 },
        proxy: { server: proxy.url, bypass: "<-loopback>" },
        serviceWorkers: "block",
        acceptDownloads: true,
        downloadsPath: tempDirectory,
        timeout: 25_000,
        args: [
          "--disable-quic",
          "--force-webrtc-ip-handling-policy=disable_non_proxied_udp",
          "--disable-extensions",
          "--host-resolver-rules=MAP * ~NOTFOUND, EXCLUDE 127.0.0.1",
        ],
      });
    } catch {
      if (!previous) await rm(directory(id), { recursive: true, force: true });
      await rm(tempDirectory, { recursive: true, force: true });
      throw new WorkerError(
        "BROWSER_UNAVAILABLE",
        "Chromium could not start. Rebuild the browser-worker image and check its resource limits.",
        503,
      );
    }
    try {
      const statePath = join(directory(id), "storage.json");
      try {
        const state = JSON.parse(await readFile(statePath, "utf8")) as Awaited<
          ReturnType<BrowserContext["storageState"]>
        >;
        await context.addCookies(state.cookies);
      } catch (error) {
        if (!(error instanceof Error && "code" in error && error.code === "ENOENT")) throw error;
      }
      await context.route("**/*", async (route) => {
        try {
          await validatePublicUrl(route.request().url());
          await route.continue();
        } catch {
          await route.abort("blockedbyclient").catch(() => {});
        }
      });
      await context.routeWebSocket("**/*", (socket) => socket.close());
      // Keep a window alive: on Linux, closing the final headed window exits
      // Chromium and makes the next newPage fail (macOS keeps the app running).
      const oldPages = context.pages();
      const page = await context.newPage();
      for (const old of oldPages) await old.close();
      page.setDefaultTimeout(10_000);
      await prepareBrowserAgent(page);
      if (control || !agent) await runBrowserAgent(page, { kind: control ?? "handoff" });
      const instance: Running = { context, page, touched: Date.now(), pending: new Set() };
      running.set(id, instance);
      const releaseFailed = () => {
        void serial(id, async () => {
          if (running.get(id) === instance) await closeSession(id, "error");
        }).catch(() => {});
      };
      context.on("close", releaseFailed);
      page.on("crash", releaseFailed);
      context.on("page", (popup) => {
        popup.on("crash", releaseFailed);
        if (instance.viewport) void popup.setViewportSize(instance.viewport).catch(() => {});
      });
      page.on("dialog", (dialog) => {
        void dialog.dismiss();
      });
      page.on("download", (download) => {
        const pending = downloads(id).then((saved) =>
          capturePdfDownload({
            directory: directory(id),
            tempDirectory,
            download,
            limitReached: saved.length + instance.pending.size > 20,
          }),
        );
        instance.pending.add(pending);
        void pending.then(
          () => instance.pending.delete(pending),
          () => {
            instance.downloadError = true;
            instance.pending.delete(pending);
          },
        );
      });
      const initial: Session = {
        id,
        archived: false,
        title: previous?.title ?? "New session",
        url,
        status: "active",
        updatedAt: new Date().toISOString(),
      };
      sessions.set(id, initial);
      await persist(initial);
      return await navigate(id, url);
    } catch (error) {
      await context.close().catch(() => {});
      await Promise.allSettled(running.get(id)?.pending ?? []);
      running.delete(id);
      if (previous) {
        const failed: Session = {
          ...previous,
          url,
          status: "error",
          updatedAt: new Date().toISOString(),
        };
        sessions.set(id, failed);
        await persist(failed);
      } else {
        sessions.delete(id);
        await rm(directory(id), { recursive: true, force: true });
      }
      await rm(tempDirectory, { recursive: true, force: true });
      throw error;
    }
  }
  const sweeper = setInterval(() => {
    for (const [id, instance] of running)
      if (Date.now() - instance.touched > idleTimeoutMs) {
        void serial(id, () => closeSession(id)).catch(() => {});
      }
  }, 60_000);
  sweeper.unref();
  return {
    list: () => [...sessions.values()],
    create: (id: string, url: string, agent = false, control?: "pause" | "handoff") =>
      serial("create", () => serial(id, () => createSession(id, url, agent, control))),
    navigate: (id: string, url: string) => sessionOperation(id, () => navigate(id, url)),
    closeSession: (id: string) => serial(id, () => closeSession(id)),
    screenshot: (id: string) =>
      sessionOperation(id, () => active(id).page.screenshot({ type: "png", timeout: 10_000 })),
    read: (id: string) =>
      sessionOperation(id, async () => {
        const { page } = active(id);
        await validatePublicUrl(page.url());
        // Evaluation is fixed by the worker; callers cannot inject JavaScript.
        const result = await page.evaluate(() => {
          const text = document.body?.innerText ?? "";
          return {
            url: location.href,
            title: document.title.slice(0, 300),
            text: text.slice(0, 100_000),
            truncated: text.length > 100_000,
          };
        });
        await validatePublicUrl(result.url);
        const session: Session = {
          id,
          archived: false,
          url: result.url,
          title: result.title,
          status: "active",
          updatedAt: new Date().toISOString(),
        };
        sessions.set(id, session);
        await persist(session);
        return result;
      }),
    input: (id: string, input: Record<string, unknown>) =>
      sessionOperation(id, async () => {
        const instance = active(id),
          { page } = instance;
        if (!agentHuman(page))
          throw new WorkerError(
            "BOOKING_CONTROLLED",
            "Hand off the booking before manual input.",
            409,
          );
        const { type, x, y, key, text, deltaY, width, height } = input;
        const viewport = page.viewportSize() ?? { width: 1280, height: 800 };
        if (
          type === "click" &&
          typeof x === "number" &&
          typeof y === "number" &&
          Number.isFinite(x) &&
          Number.isFinite(y) &&
          x >= 0 &&
          x < viewport.width &&
          y >= 0 &&
          y < viewport.height
        )
          await page.mouse.click(x, y);
        else if (type === "text" && typeof text === "string" && text.length <= 10_000)
          await page.keyboard.insertText(text);
        else if (
          type === "key" &&
          typeof key === "string" &&
          /^(Enter|Tab|Escape|Backspace|Delete|ArrowUp|ArrowDown|ArrowLeft|ArrowRight|Home|End|PageUp|PageDown|Control\+a|Meta\+a|Shift\+Tab)$/.test(
            key,
          )
        )
          await page.keyboard.press(key);
        else if (
          type === "scroll" &&
          typeof deltaY === "number" &&
          Number.isFinite(deltaY) &&
          Math.abs(deltaY) <= 5000
        )
          await page.mouse.wheel(0, deltaY);
        else if (
          type === "viewport" &&
          typeof width === "number" &&
          typeof height === "number" &&
          Number.isInteger(width) &&
          Number.isInteger(height) &&
          width >= 320 &&
          width <= 1920 &&
          height >= 240 &&
          height <= 1200
        ) {
          instance.viewport = { width, height };
          await page.setViewportSize(instance.viewport);
        } else throw new WorkerError("INVALID_INPUT", "Unsupported browser input or coordinates.");
        return refresh(id);
      }),
    agent: (id: string, command: BrowserAgentCommand) =>
      sessionOperation(id, async () => {
        if (command.kind === "handoff" && !running.has(id)) {
          const saved = sessions.get(id);
          if (!saved) throw new WorkerError("NOT_FOUND", "Browser session not found", 404);
          return { url: saved.url };
        }
        const result = await runBrowserAgent(active(id).page, command);
        await refresh(id);
        return result;
      }),
    downloads: (id: string) =>
      serial(id, async () => {
        const saved = await downloads(id);
        if (running.get(id)?.downloadError)
          throw new WorkerError(
            "DOWNLOAD_STORE_FAILED",
            "A download outcome could not be saved. Check worker storage and try again.",
            500,
          );
        return { downloads: saved, failures: await readDownloadFailures(directory(id)) };
      }),
    download: (id: string, downloadId: string) =>
      serial(id, async () => {
        validateSessionId(downloadId);
        const metadata = (await downloads(id)).find((item) => item.id === downloadId);
        if (!metadata) throw new WorkerError("DOWNLOAD_NOT_FOUND", "PDF download not found.", 404);
        const path = join(directory(id), "downloads", `${downloadId}.pdf`);
        const info = await stat(path);
        if (info.size > MAX_DOWNLOAD_BYTES)
          throw new WorkerError("DOWNLOAD_TOO_LARGE", "The PDF exceeds 10 MiB.", 413);
        return { metadata, bytes: await readFile(path) };
      }),
    close: async () => {
      clearInterval(sweeper);
      await Promise.allSettled([...queues.values()]);
      await Promise.allSettled([...running.keys()].map((id) => serial(id, () => closeSession(id))));
      await proxy.close();
    },
  };
}
